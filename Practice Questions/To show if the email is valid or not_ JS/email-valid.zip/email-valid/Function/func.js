


    var email = document.getElementById('email');


    let border_out = email.style.border;
    email.addEventListener('input', IsValidEmail);

function IsValidEmail(){
    // console.log("still change detected");
    let text = email.value;

let at =0;
    //calculating at symbols
    for(let i = 0; i<text.length;i++){
         if(text.charAt(i) == '@'){
            at++;


         }
    }
    console.log(at);
    //calculated

    if(text.includes(' ') ||  /[0-9]/.test(text.charAt(0)) || at > 1 || /[^a-zA-Z0-9@]/.test(text)){
        email.style.border = "3px solid red";
    }
    else if(/[a-z0-9]/.test(text) || at == 1 || text.includes('.')){
        email.style.border = email.style.border = "3px solid green";
    }
    else if(text.length == 0){
        email.style.border = "3px solid grey";
    }
    else{
        email.style.border = "3px solid red";

    }








}

/*Valid
1. Dots
2. @ only 1 time
3. alphabets
4. numerals

NOT valid
1. numerals at start
2. spaces*/

