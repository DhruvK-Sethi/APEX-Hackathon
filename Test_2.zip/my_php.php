<?php
  if($_SERVER['REQUEST_METHOD'=='POST']) {

  $servername="localhost";
  $username="root";
  $password="";
  $database="test";
  
  $conn=mysqli_connect($servername, $username, $password, $database);
  
  $name=$_POST['name'];
  $email=$_POST['email'];
  $address=$_POST['address'];
  $message=$_POST['message'];
  
  $sql= "INSERT INTO `users` (`Name`, `Email`, `Address`, `Message`) VALUES ('$name', '$email', '$address', '$message');";
  $result = mysqli_query($conn , $sql);

  if($result) {
    echo "Data Submitted Sucessfully...";
  }
  else {
    echo "Data not Submitted Sucessfully...";

  }

  
}
?>
